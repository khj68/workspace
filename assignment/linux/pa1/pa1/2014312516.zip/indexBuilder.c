/*-----------------------------------------------------------
 *
 * SSE2033: System Software Edigitperiment 2 (Spring 2017)
 *
 * Skeleton code for PA#1
 * 
 * March 21, 2017.
 * CSLab, Sungkyunkwan University
 *
 * Student Id   :
 * Student Name :
 *
 *-----------------------------------------------------------
 */

#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#define BYTE_SIZE 512


int fdR, fdW;
int jangSum = 0, julSum = 0, wordCount = 0, listCount=0, julCount = 0, indexCount = 0;
int currentJang = 0;
int ans_i;
char ans[50];

typedef struct Tree{ //장, 절, 위치를 담을 곳
	int jang;
	int jul;
	int location;
	struct Tree* next;
}Tree;

typedef struct Queue{ //word마다 Queue를 사용하여 Tree를 보관할 것
	Tree* first;
	Tree* last;
	int count;
}Queue;

typedef struct List{ //word마다 생성되며 linkedList 사용
	char word[23];
	struct List* next;
	int howMany;
	Queue *queue;
}List;

List *head;

void newQueue(List *list){ //새로운 큐를 초기화 하는 것
	list->queue = (Queue*)malloc(sizeof(Queue));
	list->queue->first = NULL;
	list->queue->last = NULL;
	list->queue->count = 0;
}

void push(List *temp, int jang, int jul, int location){ //큐에 트리를 넣는 것
	Tree *new = (Tree*)malloc(sizeof(Tree));
	new->jang = jang;
	new->jul = jul;
	new->location = location;
	new->next = NULL;
	if(temp->queue->count == 0){
		temp->queue->first = new;
	}else{
		temp->queue->last->next=new;
	}
	temp->queue->last = new;
	temp->queue->count++;
}

void pop(List *list){ //큐에서 트리를 빼는 것
	Tree *now;
	
	now = list->queue->first;
	list->queue->first = now->next;
	free(now);
	list->queue->count--;
}

int pass(char *buf,int i){ //중간에 관계없는 절 처리
	while(buf[i] != '\n'){
		i++;
	}
	i+=2;
	return i;
}

void createList(char *word){ //새로운 word가 나타나면 linkedList에 추가하는 것
	int i=0;
	indexCount++;
	List *newList = (List *)malloc(sizeof(List));
	newList->next = head->next;
	newList->howMany = 1;
	head->next = newList;
	while(word[i] != '\0')
	{
		if(word[i]<=90 && word[i] >= 65){
			word[i] += 32; // 대문자를 소문자로 변환
		}
		newList->word[i] = word[i];
		i++;
	}
	newQueue(newList);
}

int getNum(char * buf) { //장과 절을 입력받는 것
	int colonCount = 0, i = 0, j = 0, numCount = 0, sum=0;
	char num[5];
	julSum=0;
	while(buf[i]==' '){i++;}
	if(!(buf[i]>=48 && buf[i]<=57)){
		i = pass(buf,i);}
	while (1) {
		if (buf[i] == ':') {
			colonCount++;
			i++;
			if (colonCount == 1) {
				for (j = 0; j < numCount; j++) {
					int ten = 1, k;
					for (k = numCount - (j + 1); k > 0; k--) {
						ten *= 10;
					}
					sum += (num[j] - '0') * ten;
				}
				currentJang = sum;
				numCount = 0;
				j = 0;
				sum = 0;
				continue;
			}
			if (colonCount == 2) {
				for (j = 0; j < numCount; j++) {
					int ten = 1, k;
					for (k = numCount - (j + 1); k > 0; k--) {
						ten *= 10;
					}
					julSum += (num[j] - '0') * ten;
				}
				julCount++;
				i++;
				break;
			}
		}
		num[j++] = buf[i++];
		numCount++;
	}
	return i;
}

int compare(char *a, char *b){ //두 문자를 비교하는 것
	int i;

	for(i=0; i<23;i++){
		if(a[i]>=65 && a[i] <= 90){
			a[i] += 32;
		}


		if(a[i]== NULL || a[i] == ' '){
			if(b[i] != NULL && b[i] != ' '){
				return 0;
			}
			continue;
		}
			

		if(a[i] != b[i]){
			return 0;
		}
		
	}
	return 1;
}

int getWord(char *buf, int i) { //주어진 파일에서 단어 단위로 구분하는 것
	char temp[23] = {NULL, };
	int temp_i = 0, new = 1, index = 0, j=0;
	List *search;
	while (1) {
		if (buf[i] == '\n') {
			i++;
			break;
		}
        
		if ((buf[i] == ' ' && buf[i-1] !=' ') 
		|| (buf[i] == 46 || (buf[i]>=33 && buf[i]<=38) || (buf[i]>=40 && buf[i] <=44) 
		|| (buf[i] >=58 && buf[i]<=64))) {
			
			wordCount++;
			new =1;

			if(buf[i+1]== '\n'){
				wordCount--;
			}

			search = head->next;
			while(search != NULL){
				if(temp[0] == NULL){
					new = 0;
 					break;
				}
				if(compare(temp, search->word) == 1){
					new = 0;
					break;
				}

				search = search->next;
			}
			if(new == 1){
					createList(temp);
			}

			if(buf[i] == 46 || (buf[i]>=33 && buf[i]<=44) || (buf[i] >=58 && buf[i]<=64)){ //특수문자 처리
				if(buf[i+1] != '\n'){
					wordCount--;
				}
			}

			if(search!=NULL) {
				if(!(buf[i-1] == 46 || (buf[i-1]>=33 && buf[i-1]<=44) || (buf[i-1] >=58 && buf[i-1]<=64))){
					search->howMany++;
					push(search, currentJang, julSum, index - temp_i);
				}
			}else{
				push(head->next, currentJang,julSum, index - temp_i);
			}

			temp_i = 0; //temp 인덱스 초기화
			for(j=0; j< 23; j++){
				temp[j] = NULL;
			} //temp 초기화
		}else if(buf[i] != ' ' && buf[i] != NULL){ //알파벳, -, '인 경우에 temp에 넣어준다.
			temp[temp_i] = buf[i];
			temp_i++;
		}

		index++;
		i++;
	}
	wordCount++;

	return i;
}

int findFirst(char *buf){ //제목에 1이 들어가는 경우가 있어서, 이 경우를 처리해주기 위함
	int i=4;
	while(1){
		if(buf[i] == '1'){
			break;
		}
		i++;
	}
	return i;
}

int digit(int a){ //자릿수를 구하는 것
	int count=1, temp;
	temp = a;
	while((temp/=10) != 0){
		count++;
	}
	return count;
}

void intToString(int digit, int sum){ //write 사용을 위해 int를 string으로 변환
	int i,count=0;
	for(i=0; i<digit; i++){
		int j;
		for(j = digit-1 -i; j>=0; j--){
			int ten=1, k;
			for(k=0; k<j; k++){
				ten *= 10;
			}
			if(count == digit){
				break;
			}
			ans[ans_i++] = sum/ten + '0';
			sum %= ten;
			count++;
		}
	}
}

void writeTitle(char *name){ //제목 작성
	int i = 0; 
	char buf[50];
	while(name[i] != '_'){
		buf[i] = name[i];
		i++;
	}
	buf[i++] = ':';
	buf[i] = ' ';
	write(fdW, buf, i+1);
}

void writeWord(List* list){ //출력파일에 word와 word빈도수 작성
	int i = 0, j =0; 
	char buf[50] ={NULL, };
	while(list->word[i] != NULL){
		buf[i] = list->word[i];
		i++;
	}
	buf[i++] = ':';
	buf[i++] = ' ';
	intToString(digit(list->howMany), list->howMany);

	ans_i = 0;
	do{
		buf[i] = ans[ans_i];
		i++;
		ans_i++;
	}while(ans[ans_i] != NULL);
	buf[i++] = ',';
	buf[i] = ' ';
	write(fdW, buf, i+1);
	
	for(i=0; i<35; i++){
		ans[i] = NULL;
	}
}

void writeIndex(List* list){ //index 작성
	int i;
	intToString(digit(list->queue->first->jang), list->queue->first->jang);
	ans[ans_i++] = ':';
	intToString(digit(list->queue->first->jul), list->queue->first->jul);
	ans[ans_i++] = ':';
	intToString(digit(list->queue->first->location), list->queue->first->location);
	ans[ans_i++] = ',';
	ans[ans_i] = ' ';

	if(list->queue->count == 1){
		ans_i--;
		ans[ans_i] = '\n';
	}

	write(fdW, ans, ans_i+1);
	
	for(i=0; i<25; i++){
		ans[i] = NULL;
	}
}

void indexBuilder(const char* inputFileNm, const char* indexFileNm)
{
	int nbytes,i;
	char *file_name = inputFileNm;
	/* Write your own C code */
	fdR = open(file_name, O_RDONLY);
	file_name = indexFileNm;
	fdW = open(file_name, O_WRONLY | O_CREAT | O_TRUNC, 0777); //index파일 생성

	writeTitle(file_name); // 제목만 작성

	char buf[BYTE_SIZE];
	read(fdR, buf, BYTE_SIZE-1);
	i = findFirst(buf);	//1장의 위치를 찾아줌
	lseek(fdR, (-BYTE_SIZE+1+i), SEEK_CUR);

	head = (List*)malloc(sizeof(List)); //linkedList head 초기화
	head->next = NULL;

	while ((nbytes = read(fdR,buf, BYTE_SIZE-1)) > 0) {
		
		i = getNum(buf); //장, 절 읽기
		i = getWord(buf, i); //단어 읽기
		if(buf[i]=='\n'){
			break; //파일 끝 도달하면 break
		}
		
		lseek(fdR, -nbytes + i, SEEK_CUR); //한 절 씩 읽기 위하여
	}
	List* search = (List*)malloc(sizeof(List));
	search = head->next;
	
	ans_i =0 ; //장 수, 절 수, 인덱스 수, 단어 수 출력
	intToString(digit(currentJang), currentJang);
	ans[ans_i++] = ' ';
	intToString(digit(julCount), julCount);
	ans[ans_i++] = ' ';
	intToString(digit(indexCount), indexCount);
	ans[ans_i++] = ' ';
	intToString(digit(wordCount), wordCount);
	ans[ans_i] = '\n';

	write(fdW, ans, ans_i +1);

	for(i=0; i<30; i++){ //출력배열 초기화
		ans[i] = NULL;
	}

	while(1){
		List* temp;
		ans_i = 0;
		writeWord(search);
		while(search->queue->count != 0){ //큐의 원소를 전부 읽으면 break
			ans_i = 0;
			writeIndex(search);
			pop(search);
		}
		if(search->next == NULL){ //linkedList 끝에 도달하면 break
			break;
		}
		temp = search;
		search = search->next;
		free(temp);
	}

	close(fdR);
	close(fdW);
}
