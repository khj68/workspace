/*-----------------------------------------------------------
 *
 * SSE2033: System Software Experiment 2 (Spring 2017)
 *
 * Skeleton code for PA#1
 * 
 * March 21, 2017.
 * CSLab, Sungkyunkwan University
 *
 * Student Id   :
 * Student Name :
 *
 *-----------------------------------------------------------
 */

#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#define BYTE_SIZE 512

void indexPrinter(const char* indexFileNm, const char* outputFileNm)
{
	/* Write your own C code */
	int fdR, fdW;
	int nbytes,i;
	char *file_name = indexFileNm;
	fdR = open(file_name, O_RDONLY);
	file_name = outputFileNm;
	fdW = open(file_name, O_WRONLY | O_CREAT | O_TRUNC, 0777); //output파일 생성


	char buf[BYTE_SIZE];


	while ((nbytes = read(fdR,buf, BYTE_SIZE-1)) > 0) {
		
		write(fdW, buf, nbytes);
	}
	

	
	close(fdR);
	close(fdW);
}
