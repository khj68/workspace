/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_457()
{
    return 3347925243U;
}

unsigned getval_298()
{
    return 2488829454U;
}

unsigned addval_289(unsigned x)
{
    return x + 3347662901U;
}

unsigned addval_225(unsigned x)
{
    return x + 3347138722U;
}

unsigned addval_283(unsigned x)
{
    return x + 2421692681U;
}

unsigned getval_497()
{
    return 2425393368U;
}

unsigned addval_312(unsigned x)
{
    return x + 3284633928U;
}

void setval_394(unsigned *p)
{
    *p = 2421689643U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_102(unsigned x)
{
    return x + 3381972617U;
}

void setval_326(unsigned *p)
{
    *p = 3515430578U;
}

unsigned addval_350(unsigned x)
{
    return x + 3286272330U;
}

void setval_461(unsigned *p)
{
    *p = 3353381192U;
}

unsigned getval_113()
{
    return 3674784392U;
}

unsigned addval_487(unsigned x)
{
    return x + 3227569801U;
}

unsigned addval_310(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_335(unsigned x)
{
    return x + 3375415945U;
}

unsigned addval_199(unsigned x)
{
    return x + 2464188744U;
}

unsigned addval_183(unsigned x)
{
    return x + 3375419785U;
}

void setval_209(unsigned *p)
{
    *p = 3223899785U;
}

unsigned addval_489(unsigned x)
{
    return x + 3221799561U;
}

unsigned addval_343(unsigned x)
{
    return x + 3269495112U;
}

unsigned addval_481(unsigned x)
{
    return x + 3264270729U;
}

unsigned addval_432(unsigned x)
{
    return x + 1623445961U;
}

unsigned getval_415()
{
    return 3682910857U;
}

unsigned addval_157(unsigned x)
{
    return x + 2425537161U;
}

void setval_321(unsigned *p)
{
    *p = 3767091237U;
}

unsigned addval_133(unsigned x)
{
    return x + 3767093355U;
}

unsigned getval_340()
{
    return 3525365385U;
}

void setval_347(unsigned *p)
{
    *p = 3252717896U;
}

unsigned getval_117()
{
    return 3224949161U;
}

unsigned addval_192(unsigned x)
{
    return x + 3374371209U;
}

void setval_226(unsigned *p)
{
    *p = 3372794377U;
}

unsigned addval_125(unsigned x)
{
    return x + 3221802633U;
}

unsigned getval_473()
{
    return 3525362345U;
}

unsigned getval_185()
{
    return 3524841097U;
}

unsigned addval_155(unsigned x)
{
    return x + 3682128265U;
}

unsigned getval_182()
{
    return 3687108233U;
}

unsigned addval_108(unsigned x)
{
    return x + 3227569801U;
}

unsigned addval_319(unsigned x)
{
    return x + 3227570569U;
}

void setval_485(unsigned *p)
{
    *p = 3675832969U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
